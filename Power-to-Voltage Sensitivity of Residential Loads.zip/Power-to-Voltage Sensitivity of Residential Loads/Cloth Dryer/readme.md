# Cloth Dryer

In around the first 18 minutes, the cloth dryer operates in the heat-up phase, followed by the drying cycles.  

![Cloth dryer](../img/ClothDryer.svg)
